'use client';
import PromptVault from './PromptVault';
export default function PromptVaultClient() {
  return <PromptVault />;
} 